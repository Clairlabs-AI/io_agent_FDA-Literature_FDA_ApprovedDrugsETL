"""Written by scripts/build_pipeline_zip.py. Do not edit by hand."""

BUILT_AT = "2026-09-04 08:52:38 UTC"
CONTENT_HASH = "4bbbaea1a2e5"
FILE_COUNT = 28
