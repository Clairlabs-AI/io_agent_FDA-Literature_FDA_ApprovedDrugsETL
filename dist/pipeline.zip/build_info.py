"""Written by scripts/build_pipeline_zip.py. Do not edit by hand."""

BUILT_AT = "2026-08-27 11:25:38 UTC"
CONTENT_HASH = "7d5cf181bed6"
FILE_COUNT = 28
